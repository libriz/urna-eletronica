
public class ControladorUrna implements IControladorUrna{
    
}
