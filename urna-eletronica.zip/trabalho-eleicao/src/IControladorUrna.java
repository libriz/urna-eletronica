
public interface IControladorUrna {
    
    /**
     * @param eleitor 
     * @param candidato 
     * @return retorna o voto
     */
    //public String votar() throws erroNoVotoException;
    
     /**
     * @return retorna o total de votos
     */
    //public String totalizar()
}
