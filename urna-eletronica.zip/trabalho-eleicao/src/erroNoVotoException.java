
public class erroNoVotoException extends RuntimeException {

    public erroNoVotoException(){
        super("Erro: erroNoVotoException");
    }
}
