
public class Eleicao {
    //getUrnas
    //getResultado
}
